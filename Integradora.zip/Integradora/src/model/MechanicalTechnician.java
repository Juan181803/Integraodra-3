package model;

public class MechanicalTechnician extends Document {
	private double gasLevel;
	public MechanicalTechnician(double price, int year, double gasLevel) {
		super(price, year);
		this.gasLevel=gasLevel;
		
	}
	public double getGasLevel() {
		return gasLevel;
	}
	public void setGasLevel(double gasLevel) {
		this.gasLevel = gasLevel;
	}
	

}

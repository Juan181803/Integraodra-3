package model;

public class HybridCars extends Automobile{
	private ChargerType chargerType;
	private double bateryDuration;
	private double gasolineCapacity;
	private TypeGasoline gasolineType;
	public HybridCars(int selectChargerType, double bateryDuration, double gasolineCapacity, int selectGasolineType, double basePrice, String brand, double displacement, double kilometers,
			String isNew, String type, int numDoors, String isPolarized, int model) {
		super(basePrice, brand, displacement, kilometers, isNew, type, numDoors, isPolarized, model);
		this.gasolineCapacity=gasolineCapacity;
		this.bateryDuration=bateryDuration;

		switch (selectGasolineType) {
		case 1:
			this.gasolineType = TypeGasoline.REGULAR;
		case 2:
			this.gasolineType = TypeGasoline.EXTRA;
			break;
		case 3:
			this.gasolineType = TypeGasoline.DIESEL;
	}
		switch (selectChargerType) {
		case 1:
			this.chargerType= ChargerType.NORMAL;
			break;
		case 2:
			this.chargerType= ChargerType.FAST;
			break;
		}
	}
	public ChargerType getChargerType() {
		return chargerType;
	}
	public void setChargerType(ChargerType chargerType) {
		this.chargerType = chargerType;
	}
	public double getBateryDuration() {
		return bateryDuration;
	}
	public void setBateryDuration(double bateryDuration) {
		this.bateryDuration = bateryDuration;
	}
	public double getGasolineCapacity() {
		return gasolineCapacity;
	}
	public void setGasolineCapacity(double gasolineCapacity) {
		this.gasolineCapacity = gasolineCapacity;
	}
	public TypeGasoline getGasolineType() {
		return gasolineType;
	}
	public void setGasolineType(TypeGasoline gasolineType) {
		this.gasolineType = gasolineType;
	}
	

}

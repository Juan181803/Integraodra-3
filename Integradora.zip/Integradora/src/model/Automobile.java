package model;

public class Automobile extends Vehicle {
	private String type;
	private int numDoors;
	private String isPolarized;
	
public Automobile(double basePrice, String brand, double displacement, double kilometers, String isNew, String type, int numDoors, String isPolarized, int model) {
	
	super(basePrice, brand, displacement, kilometers, isNew, model);

this.type=type;
this.numDoors=numDoors;
this.isPolarized= isPolarized;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public int getNumDoors() {
	return numDoors;
}

public void setNumDoors(int numDoors) {
	this.numDoors = numDoors;
}

public String getIsPolarized() {
	return isPolarized;
}

public void setIsPolarized(String isPolarized) {
	this.isPolarized = isPolarized;
}


}

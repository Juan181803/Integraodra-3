package model;

public class Motorcycle extends Vehicle{

	private MotoType typeMoto;
	private double gasolineCapacity;
	
	public Motorcycle(int type, double gasolineCapacity, double basePrice, String brand, double displacement, double kilometers, String isNew, int model) {
		super(basePrice,brand,displacement, kilometers,isNew, model);
		this.gasolineCapacity= gasolineCapacity;
		switch (type) {
		case 1:
			this.typeMoto = MotoType.STANDARD;
			break;
		case 2:
			this.typeMoto = MotoType.SPORT;
			break;
		case 3:
			this.typeMoto = MotoType.SCOOTER; 
			break;
		case 4:
			this.typeMoto = MotoType.CROSS; 
			break;
		}
	}

	public double getGasolineCapacity() {
		return gasolineCapacity;
	}

	public void setGasolineCapacity(double gasolineCapacity) {
		this.gasolineCapacity = gasolineCapacity;
	}

	public MotoType getTypeMoto() {
		return typeMoto;
	}

	public void setTypeMoto(MotoType typeMoto) {
		this.typeMoto = typeMoto;
	}
	
}

package model;

public enum TypeGasoline {
	REGULAR, EXTRA, DIESEL;

}

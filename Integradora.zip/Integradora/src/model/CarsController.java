package model;

import java.util.ArrayList;

public class CarsController {
	
	ArrayList<Vehicle> carsList;
	
	
	public CarsController() {
		this.carsList = new ArrayList<Vehicle>();
	
		//String parking[][] = [5][10];
	}

	
	public boolean registerGasolineVehicle(double gasolineCapacity, int typeGas, double basePrice, String brand, double displacement, double kilometers, String isNew, String type, int numDoors, String isPolarized, int model) {
		
		return carsList.add(new GasolineVehicles(gasolineCapacity, typeGas, basePrice, brand, displacement, kilometers, isNew, type, numDoors, isPolarized, model));
		
	}
public boolean registerElectricVehicles(int typeSwitch, double bateryDuration, double basePrice,  String brand, double displacement, double kilometers, String isNew, String type, int numDoors, String isPolarized, int model) {
		
		return carsList.add(new ElectricCars(typeSwitch, bateryDuration, basePrice, brand, displacement, kilometers, isNew, type, numDoors, isPolarized, model));
		
	}
public boolean registerMotorbike(int type, double gasolineCapacity, double basePrice, String brand, double displacement, double kilometers, String isNew, int model) {
	return carsList.add(new Motorcycle(type, gasolineCapacity, basePrice,brand,displacement,kilometers,isNew,model ));
}
public boolean registerHybridVehicles(int selectChargerType, double bateryDuration, double gasolineCapacity, int selectGasolineType, double basePrice, String brand, double displacement, double kilometers,
		String isNew, String type, int numDoors, String isPolarized, int model) {
	
	return carsList.add(new HybridCars(selectChargerType, bateryDuration, gasolineCapacity, selectGasolineType, basePrice, brand, displacement, kilometers, isNew, type, numDoors, isPolarized, model));
}
public boolean registerDocumentPropertyCard(int position, double price, int year) {
	return carsList.get(position).addDocumentPropertyCard(price, year);
}

public boolean registerDocumentSoat(int position, double price, int year, double coverage ) {
	return carsList.get(position).addDocumentSoat(price, year, coverage);
}
public boolean registerMechanicanTechnician(int position, double price, int year, double gasLevel) {
	return carsList.get(position).addDocumentMechanicalTechnician(price, year, gasLevel);
}
public String showCars() {
	String out = "";
	for (int i = 0; i<carsList.size(); i++) {
		out += carsList.toString();
	}
	return out;
}

public double calculateTotalPrice(int car) {
	double sellingPrice = 0;
	if(carsList.get(car).getSoat().getYear() < 2022 || carsList.get(car).getMechanicalTechnician().getYear() <2022) {
		sellingPrice+=500000;
	}
	if (carsList.get(car) instanceof ElectricCars) {
		sellingPrice+= carsList.get(car).getBasePrice() * 1.2;
		if(carsList.get(car).getIsNew()== "No") {
			sellingPrice=sellingPrice*0.9;
		}
	}else if(carsList.get(car) instanceof HybridCars) {
		sellingPrice+=carsList.get(car).getBasePrice()*1.15;
		if(carsList.get(car).getIsNew()== "No") {
			sellingPrice=sellingPrice*0.9;
		}
	}else if(carsList.get(car) instanceof Motorcycle) {
		sellingPrice+= carsList.get(car).getBasePrice()*1.04;
		if(carsList.get(car).getIsNew()== "No") {
			sellingPrice=sellingPrice*0.98;
		}
		
		
	
}
	carsList.get(car).setSellingPrice(sellingPrice);
	
	return sellingPrice;
}
public String informeTypeVehicle() {
String out = "";
for (int i = 0; i<carsList.size(); i++) {
	out +="\nBrand:" + carsList.get(i).getBrand() + "\nIs New?:" + carsList.get(i).getIsNew() + "\nModel:" + carsList.get(i).getModel() + "\nKilometers:" +carsList.get(i).getKilometers() + "\nselling Price:" +carsList.get(i).getSellingPrice()+ "\nbase price" + carsList.get(i).getBasePrice();
}

return out;
}

public String informeUsedCar() {
	String out = "";
	for (int i = 0; i<carsList.size(); i++) {
		if (carsList.get(i).getIsNew() == "No") {
		out +="\nBrand:" + carsList.get(i).getBrand() + "\nIs New?:" + carsList.get(i).getIsNew() + "\nModel:" + carsList.get(i).getModel() + "\nKilometers:" +carsList.get(i).getKilometers() + "\nselling Price:" +carsList.get(i).getSellingPrice()+ "\nbase price" + carsList.get(i).getBasePrice();
	}
	}

	return out;
	}
public String informeNewCar() {
	String out = "";
	for (int i = 0; i<carsList.size(); i++) {
		if (carsList.get(i).getIsNew() == "Yes") {
		out +="\nBrand:" + carsList.get(i).getBrand() + "\nIs New?:" + carsList.get(i).getIsNew() + "\nModel:" + carsList.get(i).getModel() + "\nKilometers:" +carsList.get(i).getKilometers() + "\nselling Price:" +carsList.get(i).getSellingPrice()+ "\nbase price" + carsList.get(i).getBasePrice();
	}
	}

	return out;
	}
}


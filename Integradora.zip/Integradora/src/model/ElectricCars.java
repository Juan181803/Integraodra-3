package model;

public class ElectricCars extends Automobile {
	private ChargerType chargerType;
	private double bateryDuration;
	
	public ElectricCars(int typeSwitch, double bateryDuration, double basePrice,  String brand, double displacement, double kilometers, String isNew, String type, int numDoors, String isPolarized, int model) {
		super( basePrice, brand,displacement, kilometers,isNew, type, numDoors, isPolarized, model);
		this.bateryDuration=bateryDuration;
		switch (typeSwitch) {
		case 1:
			this.chargerType= ChargerType.NORMAL;
			break;
		case 2:
			this.chargerType= ChargerType.FAST;
			break;
		}
	}

	public ChargerType getChargerType() {
		return chargerType;
	}

	public void setChargerType(ChargerType chargerType) {
		this.chargerType = chargerType;
	}

	public double getBateryDuration() {
		return bateryDuration;
	}

	public void setBateryDuration(double bateryDuration) {
		this.bateryDuration = bateryDuration;
	}

}

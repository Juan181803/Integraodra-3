package model;

import java.util.ArrayList;

public class Vehicle {
	private double basePrice;

	private String brand;
	private double displacement;
	private double kilometers;
	private String isNew;
	private int model;
	ArrayList<Document> documentList;
	protected Soat soat;
	protected MechanicalTechnician mechanicalTechnician;
	protected PropertyCard propertyCard;
	private double sellingPrice;

	public Soat getSoat() {
		return soat;
	}

	public void setSoat(Soat soat) {
		this.soat = soat;
	}

	public MechanicalTechnician getMechanicalTechnician() {
		return mechanicalTechnician;
	}

	public void setMechanicalTechnician(MechanicalTechnician mechanicalTechnician) {
		this.mechanicalTechnician = mechanicalTechnician;
	}

	public PropertyCard getPropertyCard() {
		return propertyCard;
	}

	public void setPropertyCard(PropertyCard propertyCard) {
		this.propertyCard = propertyCard;
	}

	public Vehicle(double basePrice, String brand, double displacement, double kilometers, String isNew, int model) {
		super();

		this.basePrice = basePrice;
		this.brand = brand;
		this.displacement = displacement;
		this.kilometers = kilometers;
		this.isNew = isNew;
		this.model = model;
		this.sellingPrice=0;
		this.documentList=new ArrayList<Document>();
		
	}
	

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getDisplacement() {
		return displacement;
	}

	public void setDisplacement(double displacement) {
		this.displacement = displacement;
	}

	public double getKilometers() {
		return kilometers;
	}

	public void setKilometers(double kilometers) {
		this.kilometers = kilometers;
	}

	public String getIsNew() {
		return isNew;
	}

	public void setIsNew(String isNew) {
		this.isNew = isNew;
	}
//crear metodo para añadir documentos al arraylist
	public boolean addDocumentPropertyCard ( double price, int year) {
		
		return documentList.add(new PropertyCard(price, year));
	}
	public boolean addDocumentSoat ( double price, int year, double coverage) {
		Soat mySoat = new Soat(price, year, coverage);
		soat = mySoat;
		return documentList.add(new Soat(price, year, coverage));
	}
public boolean addDocumentMechanicalTechnician ( double price, int year, double gasLevel) {
		MechanicalTechnician myMechanicalTechnician = new MechanicalTechnician(price, year, gasLevel);
		mechanicalTechnician = myMechanicalTechnician;
	return documentList.add(new MechanicalTechnician(price, year, gasLevel));
	}
	
	@Override
	public String toString() {
		
	return  "\nCar info: \nBrand:" + brand + "\n Model:" + model + "\n Base price: " +basePrice;
	}
	public String toString2() {
		
	return  "\nCar info: \nBrand:" + brand + "\n Model:" + model + "\n Base price: " + basePrice + "\ndisplacement" + displacement + "\nkilometers:" + kilometers + "Is new?:" +isNew ;
	}

}


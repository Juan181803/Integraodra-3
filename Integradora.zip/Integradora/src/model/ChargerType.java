package model;

public enum ChargerType {
NORMAL, FAST;
}

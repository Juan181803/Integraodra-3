package model;

public enum MotoType {
 STANDARD, SPORT, SCOOTER, CROSS;
}

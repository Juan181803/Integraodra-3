package ui;

import java.util.Scanner;

import model.CarsController;
import model.Vehicle;


public class CarsManager {


private static Scanner reader;
private static CarsController carsController;

public static void main(String[] args) {

	init();
	showMenu();

}

public static void init() {

	reader = new Scanner(System.in);
	carsController = new CarsController();

}

public static void showMenu() {

	System.out.println("Welcome to concessionaire");



	boolean stopFlag = false;

	while (stopFlag == false) {

		System.out.println("\nType an option");
		System.out.println("1. Register a Vehicle");
		System.out.println("2. Register a Document");
		System.out.println("3. Calculate total price");
		System.out.println("4. Generate Report");
		
	
		int mainOption = reader.nextInt();
		switch (mainOption) {
		case 1:
			registerCar();
			break;
		case 2:
			registerDocument();
			break;
		case 3:
			calculateTotalPrice();
		case 4: informe();
			
		
	}

		
	}

}
private static void informe() {
	System.out.println("What type of report do you want?: \n1. type of vehicle \n2 type of gas \n3. Is new or not");
	int type = reader.nextInt();
	switch(type) {
	case 1: System.out.println(carsController.informeTypeVehicle());
		break; 
	case 2:
		break;
	case 3: 
		System.out.println("Do you want tu see new cars or used cars? \n1. new \n2.Used");
		int newOrUsed = reader.nextInt();
		switch (newOrUsed) {
		case 1 : System.out.println(carsController.informeNewCar());
		break;
		case 2: System.out.println(carsController.informeUsedCar());
		}
		
	}
	
}

public static void calculateTotalPrice() {
	System.out.println("For waht car do you want to calculate the total price");
	System.out.println(carsController.showCars());
	int car = reader.nextInt();
	car=car-1;
	
System.out.println(carsController.calculateTotalPrice(car));
}

public static void registerCar() {
	System.out.println("What type of vehicle do you want to register: \n Select \n1. Gasoline vehicle\n2. Electric Cars \n3 Hybrid Cars\n4 Motorcycle");
	int typeOfCar = reader.nextInt();
	switch (typeOfCar) {
	case 1:
		System.out.println("Type the gasoline capacity of the vehicle");
		double gasolineCapacity = reader.nextDouble();
		System.out.println("Select the type of gasoline that use the vehicle. \n1 Regular\n2 Extra \n3 Diesel");
		int gastype = reader.nextInt();
		System.out.println("Type the price base of the vehicle");
		double basePrice = reader.nextDouble();
		System.out.println("what is te brand of the vehicle");
		String brand = reader.nextLine();
		brand = reader.nextLine();
		System.out.println("type the displacement (cilindraje) of the vehicle");
		double displacement = reader.nextDouble();
		System.out.println("type the kilimeters that has the vehicle");
		double kilometers = reader.nextDouble();
		System.out.println("the vehicle is new? \n1. Yes \n2. No");
		String isNew = reader.next();
		System.out.println("type the type of the vehicle: (sedan or van)");
		String type = reader.next();
		System.out.println("type the number or doors that the vehicle has");
		int numDoors = reader.nextInt();
		System.out.println("Type if the vehicle is polarized: \n1. No \n2. Yes");
		String isPolarized = reader.next();
		System.out.println("type the model of the vehicle (year)");
		int model = reader.nextInt();
		if (carsController.registerGasolineVehicle(gasolineCapacity, gastype, basePrice, brand, displacement, kilometers, isNew, type, numDoors, isPolarized, model )) {
			System.out.println("the vehicle was succesfully registered");
			
			
		}else {
			System.out.println("Vehicle can not been registered");
			
		}
	
	break;
case 2:
	System.out.println("What type of charger has the vehicle: \n1. Normal \n2. Fast");
	int chargertype = reader.nextInt();
	System.out.println("type the batery duration");
	double bateryDuration = reader.nextDouble();
	System.out.println("Type the price base of the vehicle");
	double basePrice2 = reader.nextDouble();
	System.out.println("what is te brand of the vehicle");
	String brand2 = reader.nextLine();
	brand2 = reader.nextLine();
	System.out.println("type the displacement (cilindraje) of the vehicle");
	double displacement2 = reader.nextDouble();
	System.out.println("type the kilimeters that has the vehicle");
	double kilometers2 = reader.nextDouble();
	System.out.println("the vehicle is new? \n1. Yes \n2. No");
	String isNew2 = reader.next();
	System.out.println("type the type of the vehicle: (sedan or van)");
	String type2 = reader.next();
	System.out.println("type the number or doors that the vehicle has");
	int numDoors2 = reader.nextInt();
	System.out.println("Type if the vehicle is polarized: \n1. No \n2. Yes");
	String isPolarized2 = reader.next();
	System.out.println("type the model of the vehicle (year)");
	int model2 = reader.nextInt();
	if (carsController.registerElectricVehicles(chargertype, bateryDuration, basePrice2, brand2, displacement2, kilometers2, isNew2, type2, numDoors2, isPolarized2, model2)) {
		System.out.println("the vehicle was succesfully registered");
		
		
	}else {
		System.out.println("Vehicle can not been registered");
	}
	break;
case 3:
	System.out.println("What type of charger has the vehicle: \n1. Normal \n2. Fast");
	int chargertype3 = reader.nextInt();
	System.out.println("type the batery duration");
	double bateryDuration3 = reader.nextDouble();
	System.out.println("Type the gasoline capacity of the vehicle");
	double gasolineCapacity3 = reader.nextDouble();
	System.out.println("Select the type of gasoline that use the vehicle. \n1 Regular\n2 Extra \n3 Diesel");
	int gastype3 = reader.nextInt();
	System.out.println("Type the price base of the vehicle");
	double basePrice3 = reader.nextDouble();
	System.out.println("what is te brand of the vehicle");
	String brand3 = reader.nextLine();
	brand3 = reader.nextLine();
	System.out.println("type the displacement (cilindraje) of the vehicle");
	double displacement3 = reader.nextDouble();
	System.out.println("type the kilimeters that has the vehicle");
	double kilometers3 = reader.nextDouble();
	System.out.println("the vehicle is new? \n1. Yes \n2. No");
	String isNew3 = reader.next();
	System.out.println("type the type of the vehicle: (sedan or van)");
	String type3 = reader.next();
	System.out.println("type the number or doors that the vehicle has");
	int numDoors3 = reader.nextInt();
	System.out.println("Type if the vehicle is polarized: \n1. No \n2. Yes");
	String isPolarized3 = reader.next();
	System.out.println("type the model of the vehicle (year)");
	int model3 = reader.nextInt();
	if (carsController.registerHybridVehicles(chargertype3, bateryDuration3, gasolineCapacity3, gastype3, basePrice3, brand3, displacement3, kilometers3, isNew3, type3, numDoors3, isPolarized3, model3)) {
		System.out.println("the vehicle was succesfully registered");
		
		
	}else {
		System.out.println("Vehicle can not been registered");
	}
	break;
case 4:
	System.out.println("What type of moto do you want to register: \n1 Standard \n2. Sport \n3. scooter \n4 cross");
	int typeOfmoto=reader.nextInt();
	System.out.println("Type the gasoline capacity of the vehicle");
	double gasolineCapacity4 = reader.nextDouble();
	System.out.println("Type the price base of the vehicle");
	double basePrice4 = reader.nextDouble();
	System.out.println("what is te brand of the vehicle");
	String brand4 = reader.nextLine();
	brand4 = reader.nextLine();
	System.out.println("type the displacement (cilindraje) of the vehicle");
	double displacement4 = reader.nextDouble();
	System.out.println("type the kilimeters that has the vehicle");
	double kilometers4 = reader.nextDouble();
	System.out.println("the vehicle is new? \n1. Yes \n2. No");
	String isNew4 = reader.nextLine();
	isNew4=reader.nextLine();
	System.out.println("type the model of the vehicle (year)");
	int model4 = reader.nextInt();
	if (carsController.registerMotorbike(typeOfmoto, gasolineCapacity4, basePrice4, brand4, displacement4,kilometers4, isNew4,model4)) {
		System.out.println("the vehicle was succesfully registered");
		
		
	}else {
		System.out.println("Vehicle can not been registered");
		
	}

break;

}
}
public static void registerDocument() {
	System.out.println("Select the car that you want to register the document for");
	System.out.println(carsController.showCars());
	int position = reader.nextInt();
	position = position - 1;
	System.out.println("Select what document do you want to register:\n1. Property Card \n2. Soat\n3. Mechanical Technician");
	int typeOfDocument = reader.nextInt();
	switch (typeOfDocument) {
	case 1:
		System.out.println("Type the price of the document");
		double price = reader.nextDouble();
		System.out.println("Type the year in wich the  document was purchased");
		int year = reader.nextInt();
		
		if (carsController.registerDocumentPropertyCard(position, price, year)) {
			System.out.println("Document succesfully registered");
			
		}else {
			System.out.println("Document can not been registered");
		}
		break;
		
	case 2: 
		System.out.println("Type the price of the document");
		double price2 = reader.nextDouble();
		System.out.println("Type the year in wich the  document was purchased");
		int year2 = reader.nextInt();
		System.out.println("type the amount of coverage for accidents to third parties");
		double coverage = reader.nextDouble();
		
		if (carsController.registerDocumentSoat(position, price2, year2, coverage)) {
			System.out.println("Document succesfully registered");
			
		}else {
			System.out.println("Document can not been registered");
		}
		break;
		
	case 3:
		System.out.println("Type the price of the document");
		double price3 = reader.nextDouble();
		System.out.println("Type the year in wich the  document was purchased");
		int year3 = reader.nextInt();
		System.out.println("type the amount of coverage for accidents to third parties");
		double gasLevel = reader.nextDouble();
		
		if (carsController.registerMechanicanTechnician(position, price3, year3, gasLevel)) {
			System.out.println("Document succesfully registered");
			
		}else {
			System.out.println("Document can not been registered");
		}
		break;
		
	
	}
}

/*private static boolean registerGasolineVehicle(double gasolineCapacity, int gastype, double basePrice, String brand,
		double displacement, double kilometers, String isNew, String type, int numDoors, String isPolarized) {
	// TODO Auto-generated method stub
	return false;
}*/
}

